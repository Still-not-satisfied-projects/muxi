# coding: utf-8

"""
	basedir.py
	~~~~~~~~~~

		the basic abs path of muxi app
"""
import os


_basedir = os.path.abspath(os.path.dirname(__file__))
