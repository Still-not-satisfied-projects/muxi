# coding: utf-8

"""
    _sql.py
    ~~~~~~~

        集成flask-sqlalchemy扩展预填代码
"""


_sql_py = '''# coding: utf-8
"""
    models.py
    ~~~~~~~~~

        数据库文件
"""
from . import db

'''
